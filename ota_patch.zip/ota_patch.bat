@echo off
setlocal EnableDelayedExpansion

:: ============================================================
::  ota_patch.bat
::  Applies one or more bsdiff or VCDIFF .patch0 files to any
::  file. Format is auto-detected per patch.
::
::  Usage:
::    ota_patch.bat <input_file> <patch1> [patch2] [patch3] ...
::
::  Examples:
::    ota_patch.bat build.prop RC8-to-RC9.patch0 RC9-to-CRB17.patch0
::    ota_patch.bat framework.jar framework.jar.patch0
::    ota_patch.bat system.img a.patch0 b.patch0 c.patch0
::
::  Requirements:
::    Python 3
::    bspatch.exe
::    xdelta3.exe
::
:: ============================================================

echo === OTA Patcher ===
echo.

:: ---- Argument check ----------------------------------------
if "%~1"=="" goto :usage
if "%~2"=="" goto :usage

:: ---- Check Python is available -----------------------------
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python 3 not found. Required for patch format detection.
    echo         Install from https://www.python.org/downloads/
    exit /b 1
)

:: ---- Write the format-detector script to a temp file -------
set "DETECT_PY=%TEMP%\ota_detect.py"
(
    echo import sys
    echo with open^(sys.argv[1], 'rb'^) as f:
    echo     b = f.read^(8^)
    echo if b[:8] == b'BSDIFF40':
    echo     print^('bsdiff'^)
    echo elif b[:3] == b'\xd6\xc3\xc4':
    echo     print^('vcdiff'^)
    echo else:
    echo     print^('unknown'^)
) > "%DETECT_PY%"

:: ---- Locate bspatch ----------------------------------------
set "BSPATCH="
where bspatch.exe >nul 2>&1
if %errorlevel%==0 (
    set "BSPATCH=bspatch.exe"
) else if exist "%~dp0bspatch.exe" (
    set "BSPATCH=%~dp0bspatch.exe"
)

:: ---- Locate xdelta3 ----------------------------------------
set "XDELTA3="
where xdelta3.exe >nul 2>&1
if %errorlevel%==0 (
    set "XDELTA3=xdelta3.exe"
) else if exist "%~dp0xdelta3.exe" (
    set "XDELTA3=%~dp0xdelta3.exe"
)

:: ---- Validate input file -----------------------------------
set "INPUT=%~f1"
if not exist "%INPUT%" (
    echo [ERROR] Input file not found: %INPUT%
    goto :final_cleanup
)
echo [OK] Input: %INPUT%

for %%F in ("%INPUT%") do (
    set "BASENAME=%%~nF"
    set "BASEEXT=%%~xF"
    set "BASEDIR=%%~dpF"
)

:: ---- Set up temp working folder ----------------------------
set "TMPDIR=%TEMP%\ota_patch_%RANDOM%"
mkdir "%TMPDIR%" 2>nul

set "CURRENT=%TMPDIR%\stage_0%BASEEXT%"
copy /y "%INPUT%" "%CURRENT%" >nul

:: ---- Shift past input arg, loop over patches ---------------
set /a STEP=0
set /a APPLIED=0
shift

:patch_loop
if "%~1"=="" goto :done

set /a STEP+=1
set "PATCH=%~f1"
set "PATCHNAME=%~nx1"

if not exist "%PATCH%" (
    echo.
    echo [ERROR] Patch file not found: %PATCH%
    goto :cleanup_fail
)

:: ---- Detect patch format via temp Python script ------------
for /f "delims=" %%M in ('python "%DETECT_PY%" "%PATCH%"') do set "PATCHFMT=%%M"

set "NEXT=%TMPDIR%\stage_%STEP%%BASEEXT%"

echo.
echo [Step %STEP%] %PATCHNAME% (%PATCHFMT%)

if "%PATCHFMT%"=="bsdiff" (
    if "%BSPATCH%"=="" (
        echo [ERROR] bspatch.exe not found.
        goto :cleanup_fail
    )
    "%BSPATCH%" "%CURRENT%" "%NEXT%" "%PATCH%"
) else if "%PATCHFMT%"=="vcdiff" (
    if "%XDELTA3%"=="" (
        echo [ERROR] xdelta3.exe not found. Required for this patch.
        goto :cleanup_fail
    )
    "%XDELTA3%" -d -s "%CURRENT%" "%PATCH%" "%NEXT%"
) else (
    echo [ERROR] Unknown patch format. Expected bsdiff ^(BSDIFF40^) or VCDIFF ^(d6 c3 c4 00^).
    goto :cleanup_fail
)

if %errorlevel% neq 0 (
    echo [ERROR] Patch failed on step %STEP% ^(exit code %errorlevel%^).
    echo         Check that the patch matches the file at this stage.
    goto :cleanup_fail
)

echo [OK] Patch applied.
set "CURRENT=%NEXT%"
set /a APPLIED+=1

shift
goto :patch_loop

:done
echo.
if %APPLIED%==0 (
    echo [WARN] No patches were applied.
    goto :cleanup_fail
)

set "OUTPUT=%BASEDIR%%BASENAME%_patched%BASEEXT%"
copy /y "%CURRENT%" "%OUTPUT%" >nul
echo [DONE] %APPLIED% patch^(es^) applied.
echo        Output: %OUTPUT%

:cleanup
rd /s /q "%TMPDIR%" 2>nul
goto :final_cleanup

:cleanup_fail
rd /s /q "%TMPDIR%" 2>nul
goto :final_cleanup_fail

:final_cleanup
del "%DETECT_PY%" 2>nul
exit /b 0

:final_cleanup_fail
del "%DETECT_PY%" 2>nul
exit /b 1

:usage
echo  Usage:   %~nx0 ^<input_file^> ^<patch1^> [patch2] [patch3] ...
echo.
echo  Examples:
echo    %~nx0 build.prop RC8-to-RC9.patch0 RC9-to-CRB17.patch0
echo    %~nx0 framework.jar framework.jar.patch0
echo    %~nx0 system.img a.patch0 b.patch0 c.patch0
echo.
echo  Patch format ^(bsdiff / VCDIFF^) is auto-detected per file.
echo  Output is saved as ^<name^>_patched^<ext^> next to the input file.
echo.
exit /b 1
